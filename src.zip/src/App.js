import { useState } from "react";
import "./App.scss";
import Header from "./components/Component/Header/Header";
import videoData from "./data/videos.json";
import videoDetailsData from "./data/video-details.json";
import CurrentVideo from "./components/Component/CurrentVideo/CurrentVideo";
import NextVideo from "./components/Component/NextVideo/NextVideo";
import Description from "./components/Component/Description/Description";

export function App() {
  const [nextVideos, setNextVideos] = useState(videosData);
  console.log(nextVideos);

  const [currentVideo, setCurrentVideo] = useState(videoDetailsData[0]);
  console.log(currentVideo);

  const handleVideoSelect = (selectedVideo) => {
    setCurrentVideo(selectedVideo);
  };

  const foundVideo = videoDetailsData.find(())

  const mainVideoId = currentVideo.id;
  console.log(currentVideo.id);

  const sideVideos = videoData.filter((video) => video.id !== mainVideoId);
  console.log(sideVideos);

  const mainVideoData = videoData.filter((video) => video.id === mainVideoId);
  console.log(mainVideoData);

  return (
    <>
      <Header />
      <CurrentVideo video={currentVideo} />
      <Description detail={mainVideoData} />
      <NextVideo videos={sideVideos} onVideoSelect={handleVideoSelect} />
    </>
  );
}

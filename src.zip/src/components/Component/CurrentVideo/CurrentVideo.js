function CurrentVideo({ video }) {
  return (
    <div key={video.id}>
      <video className="video" controls poster={video.image}></video>
    </div>
  );
}

export default CurrentVideo;
